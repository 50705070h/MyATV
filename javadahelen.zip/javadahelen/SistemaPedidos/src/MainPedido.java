public class MainPedido {
    public static void main(String[] args) {

         System.out.println("----------------------------------------------------------");
        
        Pedido pedido = new Pedido();
        

        pedido.adicionarItem("Teclado", 8, 150.0);

       
        
        pedido.adicionarItem("Mouse", 2, 80.0);
       
        

        pedido.mostrarPedido();
      
        
    }
}
