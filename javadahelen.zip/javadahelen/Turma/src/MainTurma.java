public class MainTurma {
    public static void main(String[] args) {
        Professor prof1 = new Professor("SAMARA");
        Turma turma = new Turma("T0010");

        turma.setProfessor(prof1);
        turma.resumo();

        System.out.println("\nTroca de professor...\n");

        Professor prof2 = new Professor("walter");
        turma.setProfessor(prof2);
        turma.resumo();
    }
}
